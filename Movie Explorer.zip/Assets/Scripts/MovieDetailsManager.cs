using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using System.Collections;
using TMPro;
using UnityEngine.SceneManagement;

public class MovieDetailsManager : MonoBehaviour
{
    public TMP_Text titleText;
    public TMP_Text descriptionText;
    public Image posterImage;
    public static Movie selectedMovie;

    void Start()
    {
        if (selectedMovie != null)
        {
            titleText.text = selectedMovie.title;
            descriptionText.text = selectedMovie.overview;
            StartCoroutine(LoadImage(selectedMovie.poster_path));
        }
    }

    private IEnumerator LoadImage(string posterPath)
    {
        string url = $"https://image.tmdb.org/t/p/w500{posterPath}";
        using (UnityWebRequest request = UnityWebRequestTexture.GetTexture(url))
        {
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                Texture2D texture = ((DownloadHandlerTexture)request.downloadHandler).texture;
                if (texture != null)
                {
                    posterImage.sprite = Sprite.Create(
                        texture,
                        new Rect(0, 0, texture.width, texture.height),
                        new Vector2(0.5f, 0.5f)
                    );
                }
                else
                {
                    Debug.LogError("Texture is null, cannot create sprite.");
                }
            }
            else
            {
                Debug.LogError("Failed to load image: " + request.error);
            }
        }
    }



    public void OnBackClicked()
    {
        SceneManager.LoadScene("MainMenuScene"); // Goes back without resetting
    }
}
