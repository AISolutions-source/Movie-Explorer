using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using TMPro;

public class APIKeyManager : MonoBehaviour
{
    public TMP_InputField apiKeyInput;
    public GameObject apiKeyPanel;
    public TMP_Text statusText; // Used for both error and success messages

    void Start()
    {
        if (PlayerPrefs.HasKey("TMDbAPIKey"))
        {
            apiKeyPanel.SetActive(false); // Hide if key exists
        }
        else
        {
            apiKeyPanel.SetActive(true);  // Show input panel
            statusText.text = ""; // Clear message on start
        }
    }

    public void ValidateAndSaveAPIKey()
    {
        string apiKey = apiKeyInput.text.Trim();
        if (!string.IsNullOrEmpty(apiKey))
        {
            StartCoroutine(CheckAPIKey(apiKey));
        }
        else
        {
            ShowMessage("API Key cannot be empty.", Color.red, 2f);
        }
    }

    private IEnumerator CheckAPIKey(string apiKey)
    {
        string testUrl = $"https://api.themoviedb.org/3/movie/550?api_key={apiKey}"; // Test request to validate API Key
        using (UnityWebRequest request = UnityWebRequest.Get(testUrl))
        {
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                PlayerPrefs.SetString("TMDbAPIKey", apiKey);
                PlayerPrefs.Save();
                StartCoroutine(ShowSuccessAndClosePanel());
            }
            else
            {
                ShowMessage("Invalid API Key. Please try again.", Color.red, 2f);
                Debug.LogError("Invalid API Key: " + request.error);
            }
        }
    }

    private void ShowMessage(string message, Color color, float duration)
    {
        statusText.text = message;
        statusText.color = color;
        StartCoroutine(HideMessageAfterDelay(duration));
    }

    private IEnumerator HideMessageAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        statusText.text = "";
    }

    private IEnumerator ShowSuccessAndClosePanel()
    {
        ShowMessage("API Key saved successfully!", Color.green, 1f);
        yield return new WaitForSeconds(1f);
        apiKeyPanel.SetActive(false);
    }
}
