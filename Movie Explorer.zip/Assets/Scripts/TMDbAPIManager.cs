using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;

public class TMDbAPIManager : MonoBehaviour
{
    private const string apiKey = "2e626cbf5909f239e97bcc00c45e01fb";
    private const string baseUrl = "https://api.themoviedb.org/3/search/movie";

    public IEnumerator SearchMovie(string query, System.Action<List<Movie>> callback)
    {
        string url = $"{baseUrl}?api_key={apiKey}&query={UnityWebRequest.EscapeURL(query)}";
        using (UnityWebRequest request = UnityWebRequest.Get(url))
        {
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                string json = request.downloadHandler.text;
                MovieSearchResult result = JsonConvert.DeserializeObject<MovieSearchResult>(json);
                callback(result.results);
            }
            else
            {
                Debug.LogError("API Error: " + request.error);
                callback(null);
            }
        }
    }
}

[System.Serializable]
public class Movie
{
    public int id;
    public string title;
    public string overview;
    public string poster_path;
}

[System.Serializable]
public class MovieSearchResult
{
    public List<Movie> results;
}
